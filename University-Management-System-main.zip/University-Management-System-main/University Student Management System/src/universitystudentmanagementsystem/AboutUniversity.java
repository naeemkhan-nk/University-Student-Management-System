package universitystudentmanagementsystem;

public class AboutUniversity {

    void OfficeOfTheVC()
    {

        System.out.println("Prof. Qazi Azizul Mowla, PhD, FIAB, AAG\n" +
                "Honorable Vice Chancellor\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 110\n" +
                "Email: vc@lus.ac.bd");
        System.out.print("\n");

        System.out.println("Mr. Jalal Uddin\n" +
                "Assistant Administrative Officer\n" +
                "Tel Office: 01313084499, Ext.111\n" +
                "Cell: 01713816365\n" +
                "Email: vcoffice@lus.ac.bd");
        System.out.print("\n");

    }

    void officeOfTheTreasurer()
    {
        System.out.println("Mr. Banamali Bhowmick\n" +
                "Treasurer\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 120\n" +
                "Cell: 01711402050\n" +
                "Email: treasurer@lus.ac.bd\n" +
                "banamalibhowmick@live.com");
        System.out.print("\n");

        System.out.println("Mr.Rajat Kanti Chakrabarty\n" +
                "Deputy Director & In Charge\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 122\n" +
                "Cell: 01721108338\n" +
                "Email: director_fa@lus.ac.bd");
        System.out.print("\n");

        System.out.println("Mohammad Shahidul Islam \n" +
                "Accounts Officer\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 123\n" +
                "Cell: 01715-861320");
        System.out.print("\n");

        System.out.println("Mr. Abul Muntaser Chowdhury\n" +
                "Assistant Accounts Officer\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 125\n" +
                "Cell: 01717848188");
        System.out.print("\n");

        System.out.println("Abdullah-Al- Mamun\n" +
                "Office Assistant\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 126\n" +
                "Cell: 01682034622");
        System.out.print("\n");

        System.out.println("Md. Hasan Ahmed \n" +
                "Accounts Assistant\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 126\n" +
                "Cell: 01911246885");
        System.out.print("\n");


    }

    void OfficeOfTheRegistrar()
    {
        System.out.println("Major (Rtd) Md. Shah Alam, Psc\n" +
                "Registrar\n" +
                "Tel Office : 01313084499, Ext. 130\n" +
                "Cell: +88-01741361385\n" +
                "E-mail: registrar@lus.ac.bd");
        System.out.print("\n");

    }

    void HRSection()
    {
        System.out.println("Mrs. Fahmidatur Rahman\n" +
                "Assistant Registrar\n" +
                "Tel Office: 01313084499, Ext.132\n" +
                "Cell: 01726242764\n" +
                "Email: academic_ro@lus.ac.bd");
        System.out.print("\n");

        System.out.println("Mr. Taj Uddin Ahmed\n" +
                "Assistant Registrar (HR)\n" +
                "Tel Office: 01313084499, Ext.131\n" +
                "Cell: 01714698491\n" +
                "Email: hr_ro@lus.ac.bd");
        System.out.print("\n");

        System.out.println("Mr. Md. Rasel Ahmed\n" +
                "Section Officer (HR)\n" +
                "Tel Office: 01313084499, Ext.132\n" +
                "Cell: 01727667575\n" +
                "Email: hr2_ro@lus.ac.bd");
        System.out.print("\n");
    }

    void logisticSection()
    {
        System.out.println("Mr. Md. Shahidul Islam\n" +
                "Section Officer(Logistic)\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 134\n" +
                "Cell: 01720303462\n" +
                "Email: logistics_ro@lus.ac.bd");
        System.out.print("\n");

        System.out.println("Mrs. Anuradha Sarkar\n" +
                "Store Keeper\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 135\n" +
                "Email: store_ro@lus.ac.bd");
        System.out.print("\n");
    }

    void admissionSection()
    {
        System.out.println("Md. Kawser Hawlader\n" +
                "Deputy Registrar (Admission)\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 170\n" +
                "Cell: 01716-871188\n" +
                "Email: admission@lus.ac.bd");
        System.out.print("\n");

        System.out.println("Syeed Sabul Hussain\n" +
                "Office Assistant (Admission)\n" +
                "Tel Office : 01313084499\n" +
                "Ext. 172\n" +
                "Cell: 01755-841864\n" +
                "Email: admission_officer3@lus.ac.bd");
        System.out.print("\n");
    }





}
